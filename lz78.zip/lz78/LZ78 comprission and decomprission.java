import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class LZ78FileCompression {

    static class Tag implements Serializable {
        int index;
        char nextChar;

        public Tag(int index, char nextChar) {
            this.index = index;
            this.nextChar = nextChar;
        }

        public String toString() {
            return "(" + index + "," + nextChar + ")";
        }
    }

    public static void compress(String inputFilePath, String outputFilePath) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
            String text = reader.readLine();
            reader.close();

            ArrayList<Tag> tags = new ArrayList<>();
            Map<String, Integer> dictionary = new HashMap<>();
            int dictIndex = 1;
            int i = 0;

            while (i < text.length()) {
                int bestIndex = 0;
                String current = "";
                int j = i;

                while (j < text.length()) {
                    current += text.charAt(j);
                    if (dictionary.containsKey(current)) {
                        bestIndex = dictionary.get(current);
                        j++;
                    } else {
                        char nextChar = (j < text.length()) ? text.charAt(j) : '\0';
                        tags.add(new Tag(bestIndex, nextChar));
                        dictionary.put(current, dictIndex++);
                        i = j + 1;
                        break;
                    }
                }
                if (j == text.length() && !current.isEmpty()) {
                    tags.add(new Tag(bestIndex, '\0'));
                    i = j;
                }
            }

            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(outputFilePath));
            out.writeObject(tags);
            out.close();
            System.out.println("Compression successful. Tags saved to: " + outputFilePath);

        } catch (IOException e) {
            System.err.println("Error during compression: " + e.getMessage());
        }
    }

    public static void decompress(String inputFilePath, String outputFilePath) {
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream(inputFilePath));
            ArrayList<Tag> tags = (ArrayList<Tag>) in.readObject();
            in.close();

            ArrayList<String> dictionary = new ArrayList<>();
            dictionary.add(""); 

            StringBuilder decompressedText = new StringBuilder();
            for (Tag tag : tags) {
                String entry = dictionary.get(tag.index);
                if (tag.nextChar != '\0') {
                    entry += tag.nextChar;
                }
                decompressedText.append(entry);
                dictionary.add(entry);
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
            writer.write(decompressedText.toString());
            writer.close();
            System.out.println("Decompression successful. Decompressed text saved to: " + outputFilePath);

        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error during decompression: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Compress text file");
            System.out.println("2. Decompress binary file");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                System.out.print("Enter the input text file path: ");
                String inputFilePath = scanner.nextLine();
                System.out.print("Enter the output binary file path : ");
                String outputFilePath = scanner.nextLine();
                compress(inputFilePath, outputFilePath);

            } else if (choice == 2) {
                System.out.print("Enter the input binary file path : ");
                String inputFilePath = scanner.nextLine();
                System.out.print("Enter the output text file path: ");
                String outputFilePath = scanner.nextLine();
                decompress(inputFilePath, outputFilePath);

            } else if (choice == 3) {
                System.out.println("Exiting program...");
                break;

            } else {
                System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}