import java.io.*;
import java.nio.file.Files;
import java.util.*;

public class ArithmeticCoding {

    static class Symbol {
        char ch;
        double low, high;

        Symbol(char ch, double low, double high) {
            this.ch = ch;
            this.low = low;
            this.high = high;
        }
    }

    // =========================
    // Build Model
    // =========================
    public static Map<Character, Symbol> buildModel(String text) {
        Map<Character, Integer> freq = new HashMap<>();

        for (char c : text.toCharArray()) {
            freq.put(c, freq.getOrDefault(c, 0) + 1);
        }

        int total = text.length();

        List<Character> chars = new ArrayList<>(freq.keySet());
        Collections.sort(chars);

        Map<Character, Symbol> model = new LinkedHashMap<>();

        double cumulative = 0.0;

        for (char c : chars) {
            double prob = (double) freq.get(c) / total;
            model.put(c, new Symbol(c, cumulative, cumulative + prob));
            cumulative += prob;
        }

        return model;
    }

    // =========================
    // Save Probabilities
    // =========================
    public static void saveModel(Map<Character, Symbol> model, String path) throws IOException {
        BufferedWriter writer = new BufferedWriter(new FileWriter(path));

        for (Symbol s : model.values()) {
            writer.write(s.ch + " " + s.low + " " + s.high);
            writer.newLine();
        }

        writer.close();
    }

    // =========================
    // Load Probabilities
    // =========================
    public static Map<Character, Symbol> loadModel(String path) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(path));
        Map<Character, Symbol> model = new LinkedHashMap<>();

        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(" ");
            char ch = parts[0].charAt(0);
            double low = Double.parseDouble(parts[1]);
            double high = Double.parseDouble(parts[2]);

            model.put(ch, new Symbol(ch, low, high));
        }

        reader.close();
        return model;
    }

    // =========================
    // Compress
    // =========================
    public static void compress(String inputPath) throws IOException {

        String text = Files.readString(new File(inputPath).toPath());

        Map<Character, Symbol> model = buildModel(text);
        saveModel(model, "probabilities.txt");

        // Minimum probability & bits
        double minProb = Double.MAX_VALUE;
        for (Symbol s : model.values()) {
            double prob = s.high - s.low;
            if (prob < minProb) minProb = prob;
        }

        int k = (int) Math.ceil(-Math.log(minProb) / Math.log(2));

        System.out.println("Minimum probability: " + minProb);
        System.out.println("Bits needed (k): " + k);

        double low = 0.0, high = 1.0;

        StringBuilder bits = new StringBuilder();
        int pendingBits = 0;

        for (char c : text.toCharArray()) {
            Symbol s = model.get(c);

            double range = high - low;
            high = low + range * s.high;
            low = low + range * s.low;

            // E1 & E2 scaling
            while (true) {
                if (high < 0.5) {
                    bits.append("0");
                    for (int i = 0; i < pendingBits; i++) bits.append("1");
                    pendingBits = 0;

                    low *= 2;
                    high *= 2;

                } else if (low >= 0.5) {
                    bits.append("1");
                    for (int i = 0; i < pendingBits; i++) bits.append("0");
                    pendingBits = 0;

                    low = (low - 0.5) * 2;
                    high = (high - 0.5) * 2;

                } else {
                    break;
                }
            }
        }

        // Final bits
        pendingBits++;
        if (low < 0.5) {
            bits.append("0");
            for (int i = 0; i < pendingBits; i++) bits.append("1");
        } else {
            bits.append("1");
            for (int i = 0; i < pendingBits; i++) bits.append("0");
        }

        // =========================
        // Write REAL binary file
        // =========================
        FileOutputStream fos = new FileOutputStream("compressed.bin");

        int b = 0, count = 0;

        for (char bit : bits.toString().toCharArray()) {
            b = (b << 1) | (bit - '0');
            count++;

            if (count == 8) {
                fos.write(b);
                count = 0;
                b = 0;
            }
        }

        if (count > 0) {
            b = b << (8 - count);
            fos.write(b);
        }

        fos.close();

        System.out.println("Compression done.");
        System.out.println("Original size: " + text.length() * 8 + " bits");
        System.out.println("Compressed size: " + bits.length() + " bits");
    }

    // =========================
    // Decompress
    // =========================
    public static void decompress(String binPath, String probPath, int textLength) throws IOException {

        Map<Character, Symbol> model = loadModel(probPath);

        byte[] bytes = Files.readAllBytes(new File(binPath).toPath());

        StringBuilder bits = new StringBuilder();

        for (byte b : bytes) {
            for (int i = 7; i >= 0; i--) {
                bits.append((b >> i) & 1);
            }
        }

        double value = 0.0;
        double fraction = 0.5;

        for (char bit : bits.toString().toCharArray()) {
            if (bit == '1') value += fraction;
            fraction /= 2;
        }

        double low = 0.0, high = 1.0;

        StringBuilder output = new StringBuilder();

        for (int i = 0; i < textLength; i++) {

            double range = high - low;
            double scaled = (value - low) / range;

            for (Symbol s : model.values()) {
                if (scaled >= s.low && scaled < s.high) {
                    output.append(s.ch);

                    high = low + range * s.high;
                    low = low + range * s.low;
                    break;
                }
            }
        }

        Files.writeString(new File("decompressed.txt").toPath(), output.toString());

        System.out.println("Decompression done.");
    }

    // =========================
    // Main
    // =========================
    public static void main(String[] args) throws Exception {

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n1. Compress");
            System.out.println("2. Decompress");
            System.out.println("3. Exit");
            System.out.print("Choice: ");

            int choice = sc.nextInt();

            if (choice == 1) {
                System.out.print("Enter input file path: ");
                String path = sc.next();
                compress(path);

            } else if (choice == 2) {
                System.out.print("Enter binary file path: ");
                String bin = sc.next();

                System.out.print("Enter probability file path: ");
                String prob = sc.next();

                System.out.print("Enter original text length: ");
                int len = sc.nextInt();

                decompress(bin, prob, len);

            } else {
                break;
            }
        }

        sc.close();
    }
}