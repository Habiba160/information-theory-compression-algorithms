import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class LZ77FileCompression {

    static class Tag {
        int index;
        int length;
        char nextChar;

        public Tag(int index, int length, char nextChar) {
            this.index = index;
            this.length = length;
            this.nextChar = nextChar;
        }

        public String toString() {
            return "(" + index + "," + length + "," + nextChar + ")";
        }
    }

    public static void compress(String inputFilePath, String outputFilePath) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
            String text = reader.readLine();
            reader.close();

            ArrayList<Tag> tags = new ArrayList<>();
            int i = 0;

            while (i < text.length()) {
                int maxLength = 0, bestIndex = 0;
                int searchBufferStart = Math.max(0, i - 255);

                for (int j = searchBufferStart; j < i; j++) {
                    int length = 0;
                    while (i + length < text.length() && text.charAt(j + length) == text.charAt(i + length)) {
                        length++;
                        if (j + length >= i) break;
                    }

                    if (length > maxLength) {
                        maxLength = length;
                        bestIndex = i - j;
                    }
                }

                char nextChar = (i + maxLength < text.length()) ? text.charAt(i + maxLength) : ' ';
                tags.add(new Tag(bestIndex, maxLength, nextChar));
                i += maxLength + 1;
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
            for (Tag tag : tags) {
                writer.write(tag.toString() + " ");
            }
            writer.close();
            System.out.println("Compression successful. Tags saved to: " + outputFilePath);

        } catch (IOException e) {
            System.err.println("Error reading or writing file: " + e.getMessage());
        }
    }

    public static void decompress(String inputFilePath, String outputFilePath) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(inputFilePath));
            String compressedText = reader.readLine();
            reader.close();

            ArrayList<Tag> tags = new ArrayList<>();
            String[] tagParts = compressedText.split(" ");

            for (String part : tagParts) {
                part = part.replaceAll("[()]", "");
                String[] values = part.split(",");
                if (values.length == 3) {
                    tags.add(new Tag(Integer.parseInt(values[0]), Integer.parseInt(values[1]), values[2].charAt(0)));
                }
            }

            StringBuilder decompressedText = new StringBuilder();
            for (Tag tag : tags) {
                int start = decompressedText.length() - tag.index;
                for (int j = 0; j < tag.length; j++) {
                    decompressedText.append(decompressedText.charAt(start + j));
                }
                if (tag.nextChar != ' ') {
                    decompressedText.append(tag.nextChar);
                }
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
            writer.write(decompressedText.toString());
            writer.close();
            System.out.println("Decompression successful. Decompressed text saved to: " + outputFilePath);

        } catch (IOException e) {
            System.err.println("Error reading or writing file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Compress text file");
            System.out.println("2. Decompress text file");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                System.out.print("Enter the input text file path: ");
                String inputFilePath = scanner.nextLine();
                System.out.print("Enter the output compressed file path: ");
                String outputFilePath = scanner.nextLine();
                compress(inputFilePath, outputFilePath);

            } else if (choice == 2) {
                System.out.print("Enter the input compressed file path: ");
                String inputFilePath = scanner.nextLine();
                System.out.print("Enter the output decompressed file path: ");
                String outputFilePath = scanner.nextLine();
                decompress(inputFilePath, outputFilePath);

            } else if (choice == 3) {
                System.out.println("Exiting program...");
                break;

            } else {
                System.out.println("Invalid choice. Try again.");
            }
        }

        scanner.close();
    }
}