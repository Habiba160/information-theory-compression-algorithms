import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class TestImageGenerator {
    
    public static void main(String[] args) {
        int width = 256;
        int height = 256;
        
        // Generate a test image with gradient and patterns
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = image.createGraphics();
        
        // Create a gradient background
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // Create a gradient from top-left to bottom-right
                int r = (int)((x / (double)width) * 255);
                int g = (int)((y / (double)height) * 255);
                int b = (int)(((x + y) / (double)(width + height)) * 255);
                Color color = new Color(r, g, b);
                image.setRGB(x, y, color.getRGB());
            }
        }
        
        // Add some geometric patterns
        g2d.setColor(Color.WHITE);
        g2d.fillOval(50, 50, 60, 60);
        
        g2d.setColor(Color.BLACK);
        g2d.fillRect(150, 100, 80, 80);
        
        g2d.setColor(Color.RED);
        g2d.fillOval(80, 150, 50, 50);
        
        g2d.setColor(Color.BLUE);
        g2d.fillRect(120, 180, 40, 40);
        
        // Add some text
        g2d.setColor(Color.YELLOW);
        g2d.setFont(new Font("Arial", Font.BOLD, 24));
        g2d.drawString("Test", 180, 50);
        
        g2d.dispose();
        
        try {
            // Create images directory if it doesn't exist
            File imagesDir = new File("images");
            if (!imagesDir.exists()) {
                imagesDir.mkdirs();
            }
            
            // Save the test image
            ImageIO.write(image, "png", new File(imagesDir, "input.png"));
            System.out.println("Test image generated: images/input.png");
            System.out.println("Dimensions: " + width + "x" + height);
            
            // Also generate a simpler test image
            BufferedImage simpleImage = new BufferedImage(128, 128, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d2 = simpleImage.createGraphics();
            
            // Simple gradient
            for (int y = 0; y < 128; y++) {
                for (int x = 0; x < 128; x++) {
                    int gray = (int)((x + y) / 2.0);
                    Color color = new Color(gray, gray, gray);
                    simpleImage.setRGB(x, y, color.getRGB());
                }
            }
            
            g2d2.setColor(Color.WHITE);
            g2d2.fillRect(30, 30, 30, 30);
            g2d2.setColor(Color.BLACK);
            g2d2.fillRect(70, 70, 30, 30);
            g2d2.dispose();
            
            ImageIO.write(simpleImage, "png", new File(imagesDir, "input_simple.png"));
            System.out.println("Simple test image generated: images/input_simple.png");
            System.out.println("Dimensions: 128x128");
            
        } catch (IOException e) {
            System.err.println("Error generating test image: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
