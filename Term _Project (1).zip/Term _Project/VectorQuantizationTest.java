import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VectorQuantizationTest {
    
    public static void main(String[] args) {
        String imagePath = "images/input.png"; // Change this to your input image path
        String reportFile = "compression_report.txt";
        
        // Test configurations: different block sizes and K values
        int[] blockSizes = {2, 4, 8}; // Different block sizes to test
        int[] kValues = {4, 8, 16, 32, 64}; // Different codebook sizes to test
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(reportFile))) {
            // Write report header
            writer.println("==============================================");
            writer.println("Vector Quantization Image Compression Report");
            writer.println("==============================================");
            writer.println("Date: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date()));
            writer.println("Input Image: " + imagePath);
            writer.println();
            
            // Get image dimensions
            BufferedImage originalImage = ImageIO.read(new File(imagePath));
            writer.println("Image Dimensions: " + originalImage.getWidth() + " x " + originalImage.getHeight());
            writer.println("Image Total Pixels: " + (originalImage.getWidth() * originalImage.getHeight()));
            writer.println();
            writer.println("==============================================");
            writer.println();
            
            // Run test cases
            for (int blockSize : blockSizes) {
                for (int K : kValues) {
                    writer.println("--------------------------------------------------");
                    writer.println("Test Case: Block Size = " + blockSize + "x" + blockSize + ", K = " + K);
                    writer.println("--------------------------------------------------");
                    
                    try {
                        VectorQuantization vq = new VectorQuantization(imagePath, blockSize, K);
                        vq.execute();
                        
                        // Save images with descriptive names
                        String grayOutput = String.format("grayscale_b%d_k%d.png", blockSize, K);
                        String reconOutput = String.format("reconstructed_b%d_k%d.png", blockSize, K);
                        vq.saveGrayscaleImage(grayOutput);
                        vq.saveReconstructedImage(reconOutput);
                        
                        // Calculate and record metrics
                        double mse = vq.calculateMSE();
                        
                        // Write detailed results to report
                        writer.println("Results:");
                        writer.println("  - Grayscale image saved: " + grayOutput);
                        writer.println("  - Reconstructed image saved: " + reconOutput);
                        writer.println("  - MSE: " + String.format("%.4f", mse));
                        
                        // Calculate compression ratios
                        int height = vq.getImageHeight();
                        int width = vq.getImageWidth();
                        int numBlocksY = (int) Math.ceil((double) height / blockSize);
                        int numBlocksX = (int) Math.ceil((double) width / blockSize);
                        int totalBlocks = numBlocksY * numBlocksX;
                        
                        int originalSizeBits = height * width * 8;
                        int bitsPerLabel = (int) Math.ceil(Math.log(K) / Math.log(2));
                        int compressedSizeWithoutCodebook = totalBlocks * bitsPerLabel;
                        int codebookSizeBits = K * blockSize * blockSize * 8;
                        int compressedSizeWithCodebook = compressedSizeWithoutCodebook + codebookSizeBits;
                        
                        double ratioWithoutCodebook = (double) originalSizeBits / compressedSizeWithoutCodebook;
                        double ratioWithCodebook = (double) originalSizeBits / compressedSizeWithCodebook;
                        
                        writer.println("  - Original size (bits): " + originalSizeBits);
                        writer.println("  - Compressed size without codebook (bits): " + compressedSizeWithoutCodebook);
                        writer.println("  - Compressed size with codebook (bits): " + compressedSizeWithCodebook);
                        writer.println("  - Compression ratio (without codebook): " + String.format("%.4f", ratioWithoutCodebook));
                        writer.println("  - Compression ratio (with codebook): " + String.format("%.4f", ratioWithCodebook));
                        
                        // Analysis comments
                        writer.println();
                        writer.println("Analysis:");
                        writer.println("  - Visual Quality: Check " + reconOutput);
                        writer.println("  - Blocking Effect: More visible with larger block sizes");
                        writer.println("  - MSE Impact: Lower MSE indicates better quality");
                        writer.println("  - Compression: Higher ratio indicates better compression");
                        
                    } catch (IOException e) {
                        writer.println("Error in test case: " + e.getMessage());
                        e.printStackTrace(writer);
                    }
                    
                    writer.println();
                    writer.println();
                }
            }
            
            writer.println("==============================================");
            writer.println("Test Summary");
            writer.println("==============================================");
            writer.println("Total test cases run: " + (blockSizes.length * kValues.length));
            writer.println();
            writer.println("Key Observations to Note:");
            writer.println("1. As block size increases:");
            writer.println("   - Blocking effect becomes more visible");
            writer.println("   - Compression ratio typically increases");
            writer.println("   - MSE may increase (quality decreases)");
            writer.println();
            writer.println("2. As K (codebook size) increases:");
            writer.println("   - Visual quality improves (lower MSE)");
            writer.println("   - Compression ratio decreases");
            writer.println("   - Codebook storage overhead increases");
            writer.println();
            writer.println("3. Trade-off between quality and compression:");
            writer.println("   - Small block size + Large K = Best quality, lowest compression");
            writer.println("   - Large block size + Small K = Lowest quality, highest compression");
            writer.println("==============================================");
            
            System.out.println("All test cases completed successfully!");
            System.out.println("Report saved to: " + reportFile);
            
        } catch (IOException e) {
            System.err.println("Error creating report file: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
