import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class VectorQuantization {
    
    private BufferedImage originalImage;
    private BufferedImage grayscaleImage;
    private BufferedImage reconstructedImage;
    private int[][] grayscalePixels;
    private int[][] reconstructedPixels;
    private int blockSize;
    private int K; // Number of vectors in codebook
    private double[][] codebook; // Codebook vectors
    private int[][] labels; // Labels for each block
    private double[][] blocks; // All blocks from the image
    
    public VectorQuantization(String imagePath, int blockSize, int K) throws IOException {
        this.blockSize = blockSize;
        this.K = K;
        
        // Read the RGB image
        originalImage = ImageIO.read(new File(imagePath));
        
        // Convert to grayscale
        grayscaleImage = convertToGrayscale(originalImage);
        
        // Get pixel array
        grayscalePixels = getPixelArray(grayscaleImage);
    }
    
    // Convert RGB image to grayscale
    private BufferedImage convertToGrayscale(BufferedImage colorImage) {
        int width = colorImage.getWidth();
        int height = colorImage.getHeight();
        BufferedImage grayImage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = colorImage.getRGB(x, y);
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;
                
                // Standard grayscale conversion: 0.299*R + 0.587*G + 0.114*B
                int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                int grayRGB = (gray << 16) | (gray << 8) | gray;
                grayImage.setRGB(x, y, grayRGB);
            }
        }
        
        return grayImage;
    }
    
    // Get pixel array from BufferedImage
    private int[][] getPixelArray(BufferedImage image) {
        int width = image.getWidth();
        int height = image.getHeight();
        int[][] pixels = new int[height][width];
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                pixels[y][x] = image.getRGB(x, y) & 0xFF;
            }
        }
        
        return pixels;
    }
    
    // Divide grayscale image into blocks (vectors)
    private void divideIntoBlocks() {
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;
        
        // Calculate number of blocks (padding if necessary)
        int numBlocksY = (int) Math.ceil((double) height / blockSize);
        int numBlocksX = (int) Math.ceil((double) width / blockSize);
        int totalBlocks = numBlocksY * numBlocksX;
        
        blocks = new double[totalBlocks][blockSize * blockSize];
        labels = new int[numBlocksY][numBlocksX];
        
        int blockIndex = 0;
        for (int by = 0; by < numBlocksY; by++) {
            for (int bx = 0; bx < numBlocksX; bx++) {
                double[] block = new double[blockSize * blockSize];
                int pixelIndex = 0;
                
                for (int y = 0; y < blockSize; y++) {
                    for (int x = 0; x < blockSize; x++) {
                        int pixelY = by * blockSize + y;
                        int pixelX = bx * blockSize + x;
                        
                        // Use padding (replicate edge pixels) if out of bounds
                        if (pixelY >= height) pixelY = height - 1;
                        if (pixelX >= width) pixelX = width - 1;
                        
                        block[pixelIndex++] = grayscalePixels[pixelY][pixelX];
                    }
                }
                
                blocks[blockIndex++] = block;
            }
        }
    }
    
    // Calculate average of all blocks (first codeword)
    private double[] calculateAverageBlock() {
        double[] average = new double[blockSize * blockSize];
        
        for (double[] block : blocks) {
            for (int i = 0; i < block.length; i++) {
                average[i] += block[i];
            }
        }
        
        for (int i = 0; i < average.length; i++) {
            average[i] /= blocks.length;
        }
        
        return average;
    }
    
    // Split a codeword into two (perturbation)
    private double[][] splitCodebook(double[][] currentCodebook) {
        double[][] newCodebook = new double[currentCodebook.length * 2][currentCodebook[0].length];
        double epsilon = 0.01; // Small perturbation factor
        
        for (int i = 0; i < currentCodebook.length; i++) {
            for (int j = 0; j < currentCodebook[i].length; j++) {
                newCodebook[2 * i][j] = currentCodebook[i][j] * (1 + epsilon);
                newCodebook[2 * i + 1][j] = currentCodebook[i][j] * (1 - epsilon);
            }
        }
        
        return newCodebook;
    }
    
    // Calculate Euclidean distance between two vectors
    private double euclideanDistance(double[] v1, double[] v2) {
        double sum = 0;
        for (int i = 0; i < v1.length; i++) {
            sum += Math.pow(v1[i] - v2[i], 2);
        }
        return Math.sqrt(sum);
    }
    
    // K-Means clustering iteration
    private double[][] kMeansIteration(double[][] codebook, double[][] blocks) {
        int[] assignments = new int[blocks.length];
        double[] clusterSums = new double[codebook.length * codebook[0].length];
        int[] clusterCounts = new int[codebook.length];
        
        // Assignment step: assign each block to nearest codeword
        for (int i = 0; i < blocks.length; i++) {
            double minDist = Double.MAX_VALUE;
            int bestIndex = 0;
            
            for (int j = 0; j < codebook.length; j++) {
                double dist = euclideanDistance(blocks[i], codebook[j]);
                if (dist < minDist) {
                    minDist = dist;
                    bestIndex = j;
                }
            }
            
            assignments[i] = bestIndex;
            clusterCounts[bestIndex]++;
            
            for (int k = 0; k < blocks[i].length; k++) {
                clusterSums[bestIndex * codebook[0].length + k] += blocks[i][k];
            }
        }
        
        // Update step: calculate new centroids
        double[][] newCodebook = new double[codebook.length][codebook[0].length];
        for (int i = 0; i < codebook.length; i++) {
            if (clusterCounts[i] > 0) {
                for (int j = 0; j < codebook[i].length; j++) {
                    newCodebook[i][j] = clusterSums[i * codebook[0].length + j] / clusterCounts[i];
                }
            } else {
                // If no blocks assigned, keep old codeword or randomly initialize
                newCodebook[i] = codebook[i].clone();
            }
        }
        
        return newCodebook;
    }
    
    // Check convergence
    private boolean hasConverged(double[][] oldCodebook, double[][] newCodebook, double threshold) {
        double maxChange = 0;
        for (int i = 0; i < oldCodebook.length; i++) {
            double change = euclideanDistance(oldCodebook[i], newCodebook[i]);
            if (change > maxChange) {
                maxChange = change;
            }
        }
        return maxChange < threshold;
    }
    
    // LBG Algorithm with splitting
    private void generateCodebook() {
        // Start with average of all blocks as first codeword
        double[][] codebook = new double[1][blockSize * blockSize];
        codebook[0] = calculateAverageBlock();
        
        // Split until we reach desired size K
        while (codebook.length < K) {
            // Split the codebook
            codebook = splitCodebook(codebook);
            
            // Run K-Means iterations until convergence
            double convergenceThreshold = 0.001;
            int maxIterations = 100;
            int iteration = 0;
            double[][] newCodebook;
            
            do {
                newCodebook = kMeansIteration(codebook, blocks);
                iteration++;
            } while (!hasConverged(codebook, newCodebook, convergenceThreshold) && iteration < maxIterations);
            
            codebook = newCodebook;
        }
        
        this.codebook = codebook;
    }
    
    // Find nearest codeword for a block
    private int findNearestCodeword(double[] block) {
        double minDist = Double.MAX_VALUE;
        int bestIndex = 0;
        
        for (int i = 0; i < codebook.length; i++) {
            double dist = euclideanDistance(block, codebook[i]);
            if (dist < minDist) {
                minDist = dist;
                bestIndex = i;
            }
        }
        
        return bestIndex;
    }
    
    // Compress the image (label each block)
    private void compressImage() {
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;
        int numBlocksY = (int) Math.ceil((double) height / blockSize);
        int numBlocksX = (int) Math.ceil((double) width / blockSize);
        
        int blockIndex = 0;
        for (int by = 0; by < numBlocksY; by++) {
            for (int bx = 0; bx < numBlocksX; bx++) {
                labels[by][bx] = findNearestCodeword(blocks[blockIndex++]);
            }
        }
    }
    
    // Reconstruct the image from labels
    private void reconstructImage() {
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;
        int numBlocksY = (int) Math.ceil((double) height / blockSize);
        int numBlocksX = (int) Math.ceil((double) width / blockSize);
        
        reconstructedPixels = new int[height][width];
        
        for (int by = 0; by < numBlocksY; by++) {
            for (int bx = 0; bx < numBlocksX; bx++) {
                int label = labels[by][bx];
                double[] block = codebook[label];
                int pixelIndex = 0;
                
                for (int y = 0; y < blockSize; y++) {
                    for (int x = 0; x < blockSize; x++) {
                        int pixelY = by * blockSize + y;
                        int pixelX = bx * blockSize + x;
                        
                        if (pixelY < height && pixelX < width) {
                            reconstructedPixels[pixelY][pixelX] = (int) block[pixelIndex++];
                        }
                    }
                }
            }
        }
        
        // Create BufferedImage from reconstructed pixels
        reconstructedImage = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int gray = reconstructedPixels[y][x];
                int grayRGB = (gray << 16) | (gray << 8) | gray;
                reconstructedImage.setRGB(x, y, grayRGB);
            }
        }
    }
    
    // Calculate Mean Square Error
    public double calculateMSE() {
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;
        double mse = 0;
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                double diff = grayscalePixels[y][x] - reconstructedPixels[y][x];
                mse += diff * diff;
            }
        }
        
        mse /= (height * width);
        return mse;
    }
    
    // Calculate compression ratio
    public void calculateCompressionRatio() {
        int height = grayscalePixels.length;
        int width = grayscalePixels[0].length;
        int numBlocksY = (int) Math.ceil((double) height / blockSize);
        int numBlocksX = (int) Math.ceil((double) width / blockSize);
        int totalBlocks = numBlocksY * numBlocksX;
        
        // Original size: each pixel is 8 bits (grayscale)
        int originalSizeBits = height * width * 8;
        
        // Compressed size without codebook: labels need log2(K) bits each
        int bitsPerLabel = (int) Math.ceil(Math.log(K) / Math.log(2));
        int compressedSizeWithoutCodebook = totalBlocks * bitsPerLabel;
        
        // Compressed size with codebook: labels + codebook
        int codebookSizeBits = K * blockSize * blockSize * 8;
        int compressedSizeWithCodebook = compressedSizeWithoutCodebook + codebookSizeBits;
        
        double ratioWithoutCodebook = (double) originalSizeBits / compressedSizeWithoutCodebook;
        double ratioWithCodebook = (double) originalSizeBits / compressedSizeWithCodebook;
        
        System.out.println("=== Compression Ratio ===");
        System.out.println("Original size (bits): " + originalSizeBits);
        System.out.println("Compressed size without codebook (bits): " + compressedSizeWithoutCodebook);
        System.out.println("Compressed size with codebook (bits): " + compressedSizeWithCodebook);
        System.out.println("Compression ratio (without codebook): " + String.format("%.4f", ratioWithoutCodebook));
        System.out.println("Compression ratio (with codebook): " + String.format("%.4f", ratioWithCodebook));
    }
    
    // Save reconstructed image
    public void saveReconstructedImage(String outputPath) throws IOException {
        // Create images directory if it doesn't exist
        File imagesDir = new File("images");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }
        File outputFile = new File(imagesDir, outputPath);
        ImageIO.write(reconstructedImage, "png", outputFile);
        System.out.println("Reconstructed image saved to: " + outputFile.getPath());
    }
    
    // Save grayscale image
    public void saveGrayscaleImage(String outputPath) throws IOException {
        // Create images directory if it doesn't exist
        File imagesDir = new File("images");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }
        File outputFile = new File(imagesDir, outputPath);
        ImageIO.write(grayscaleImage, "png", outputFile);
        System.out.println("Grayscale image saved to: " + outputFile.getPath());
    }
    
    // Getter for grayscalePixels
    public int[][] getGrayscalePixels() {
        return grayscalePixels;
    }
    
    // Getter for image height
    public int getImageHeight() {
        return grayscalePixels.length;
    }
    
    // Getter for image width
    public int getImageWidth() {
        return grayscalePixels[0].length;
    }
    
    // Getter for blockSize
    public int getBlockSize() {
        return blockSize;
    }
    
    // Getter for K
    public int getK() {
        return K;
    }
    
    // Main execution method
    public void execute() throws IOException {
        System.out.println("=== Vector Quantization Image Compression ===");
        System.out.println("Block size: " + blockSize + "x" + blockSize);
        System.out.println("Codebook size (K): " + K);
        System.out.println();
        
        // Step 2: Divide image into blocks
        System.out.println("Step 1: Dividing image into blocks...");
        divideIntoBlocks();
        System.out.println("Number of blocks: " + blocks.length);
        System.out.println();
        
        // Step 3: Generate codebook using LBG algorithm
        System.out.println("Step 2: Generating codebook using LBG algorithm...");
        generateCodebook();
        System.out.println("Codebook generated with " + codebook.length + " vectors");
        System.out.println();
        
        // Step 4 & 5: Compress image (label each block)
        System.out.println("Step 3: Compressing image (labeling blocks)...");
        compressImage();
        System.out.println("Image compression complete");
        System.out.println();
        
        // Step 6: Reconstruct image
        System.out.println("Step 4: Reconstructing image...");
        reconstructImage();
        System.out.println("Image reconstruction complete");
        System.out.println();
        
        // Step 7: Calculate MSE
        System.out.println("Step 5: Calculating Mean Square Error...");
        double mse = calculateMSE();
        System.out.println("Mean Square Error (MSE): " + String.format("%.4f", mse));
        System.out.println();
        
        // Step 8: Calculate compression ratio
        calculateCompressionRatio();
    }
    
    public static void main(String[] args) {
        try {
            // Example usage - modify these parameters as needed
            String imagePath = "images/input.png"; // Path to input RGB image
            int blockSize = 4; // Block size (e.g., 2x2, 4x4, 8x8)
            int K = 16; // Number of vectors in codebook (should be power of 2 for LBG)
            
            VectorQuantization vq = new VectorQuantization(imagePath, blockSize, K);
            vq.execute();
            
            // Save images
            vq.saveGrayscaleImage("grayscale.png");
            vq.saveReconstructedImage("reconstructed.png");
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
