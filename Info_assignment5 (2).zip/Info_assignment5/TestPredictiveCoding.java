import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.ArrayList;
import java.util.List;

public class TestPredictiveCoding {
    
    public static void main(String[] args) {
        String imagePath = "test_image.png"; // Change this to your test image path
        
        // Test all combinations
        int[] predictorTypes = {1, 2, 3};
        int[] quantLevels = {8, 16, 32};
        
        List<TestResult> results = new ArrayList<>();
        
        try {
            BufferedImage originalImage = ImageIO.read(new File(imagePath));
            int width = originalImage.getWidth();
            int height = originalImage.getHeight();
            
            System.out.println("Testing with image: " + imagePath);
            System.out.println("Image size: " + width + "x" + height);
            System.out.println("Total pixels: " + (width * height));
            System.out.println();
            
            int[][] originalPixels = PredictiveCoding.convertToGrayscale(originalImage, width, height);
            
            for (int predictorType : predictorTypes) {
                for (int quantLevel : quantLevels) {
                    System.out.println("Testing: " + PredictiveCoding.getPredictorName(predictorType) + 
                                       " with " + quantLevel + " quantization levels...");
                    
                    PredictiveCoding.PredictiveCodingResult result = 
                        PredictiveCoding.performPredictiveCoding(
                            originalPixels, width, height, predictorType, quantLevel
                        );
                    
                    double mse = PredictiveCoding.calculateMSE(
                        originalPixels, result.reconstructedPixels, width, height
                    );
                    
                    double compressionRatio = PredictiveCoding.calculateCompressionRatio(
                        originalPixels, result.encodedData, width, height, quantLevel
                    );
                    
                    double psnr = 10 * Math.log10((255.0 * 255.0) / mse);
                    
                    // Create output directory if it doesn't exist
                    File outputDir = new File("output");
                    if (!outputDir.exists()) {
                        outputDir.mkdir();
                    }
                    
                    // Save reconstructed image
                    BufferedImage reconstructedImage = 
                        PredictiveCoding.createBufferedImage(result.reconstructedPixels, width, height);
                    String outputFileName = "output/reconstructed_pred" + predictorType + "_q" + quantLevel + ".png";
                    ImageIO.write(reconstructedImage, "png", new File(outputFileName));
                    
                    TestResult testResult = new TestResult(
                        predictorType, quantLevel, mse, compressionRatio, psnr, outputFileName
                    );
                    results.add(testResult);
                    
                    System.out.println("  MSE: " + String.format("%.4f", mse));
                    System.out.println("  PSNR: " + String.format("%.4f", psnr) + " dB");
                    System.out.println("  Compression Ratio: " + String.format("%.4f", compressionRatio));
                    System.out.println("  Saved: " + outputFileName);
                    System.out.println();
                }
            }
            
            // Generate report
            generateReport(results, width * height);
            System.out.println("Report generated: report.txt");
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
            System.out.println("Please ensure 'test_image.png' exists in the project directory.");
        }
    }
    
    public static void generateReport(List<TestResult> results, int totalPixels) throws IOException {
        FileWriter writer = new FileWriter("report.txt");
        
        writer.write("==============================================\n");
        writer.write("2-D Feed Backward Predictive Coding Report\n");
        writer.write("==============================================\n\n");
        
        writer.write("Assignment: DSAI 325 - Introduction to Information Theory\n");
        writer.write("Assignment 5: JAVA Implementation of 2-D Feed Backward Predictive Coding\n\n");
        
        writer.write("Test Image: test_image.png\n");
        writer.write("Total Pixels: " + totalPixels + "\n");
        writer.write("Original Size: " + totalPixels + " bytes (8 bits per pixel)\n\n");
        
        writer.write("==============================================\n");
        writer.write("Results Summary\n");
        writer.write("==============================================\n\n");
        
        writer.write(String.format("%-15s %-10s %-10s %-10s %-10s\n", 
            "Predictor", "Q-Levels", "MSE", "PSNR(dB)", "CR"));
        writer.write(String.format("%-15s %-10s %-10s %-10s %-10s\n", 
            "---------", "--------", "---", "-------", "--"));
        
        for (TestResult result : results) {
            writer.write(String.format("%-15s %-10d %-10.4f %-10.4f %-10.4f\n",
                PredictiveCoding.getPredictorName(result.predictorType),
                result.quantLevel,
                result.mse,
                result.psnr,
                result.compressionRatio
            ));
        }
        
        writer.write("\n==============================================\n");
        writer.write("Detailed Analysis\n");
        writer.write("==============================================\n\n");
        
        writer.write("1. Predictor Type Analysis:\n");
        writer.write("   - Order-1: Uses only the left neighbor pixel for prediction.\n");
        writer.write("   - Order-2: Uses left, top, and top-left neighbors for prediction.\n");
        writer.write("   - Adaptive 2-D: Dynamically selects prediction based on local context.\n\n");
        
        writer.write("2. Quantization Level Analysis:\n");
        writer.write("   - Higher quantization levels (more levels) preserve more detail but reduce compression.\n");
        writer.write("   - Lower quantization levels (fewer levels) increase compression but introduce more error.\n\n");
        
        writer.write("3. Performance Metrics:\n");
        writer.write("   - MSE (Mean Squared Error): Lower is better (less reconstruction error).\n");
        writer.write("   - PSNR (Peak Signal-to-Noise Ratio): Higher is better (better quality).\n");
        writer.write("   - CR (Compression Ratio): Higher is better (better compression).\n\n");
        
        writer.write("4. Observations:\n");
        
        // Analyze results by quantization level
        writer.write("   Analysis by Quantization Level:\n\n");
        
        for (int q : new int[]{8, 16, 32}) {
            writer.write("   Q=" + q + " levels:\n");
            double mse1 = 0, mse2 = 0, mse3 = 0;
            for (TestResult result : results) {
                if (result.quantLevel == q) {
                    if (result.predictorType == 1) mse1 = result.mse;
                    if (result.predictorType == 2) mse2 = result.mse;
                    if (result.predictorType == 3) mse3 = result.mse;
                }
            }
            writer.write("     Order-1 MSE: " + String.format("%.4f", mse1) + "\n");
            writer.write("     Order-2 MSE: " + String.format("%.4f", mse2) + "\n");
            writer.write("     Adaptive MSE: " + String.format("%.4f", mse3) + "\n");
            
            if (mse3 < mse1 && mse3 < mse2) {
                writer.write("     -> Adaptive predictor performs best\n");
            } else if (mse2 < mse1 && mse2 < mse3) {
                writer.write("     -> Order-2 predictor performs best\n");
            } else {
                writer.write("     -> Order-1 predictor performs best\n");
            }
            writer.write("\n");
        }
        
        // Overall best
        double bestMSE = Double.MAX_VALUE;
        String bestPredictorMSE = "";
        for (TestResult result : results) {
            if (result.mse < bestMSE) {
                bestMSE = result.mse;
                bestPredictorMSE = PredictiveCoding.getPredictorName(result.predictorType) + 
                                   " (Q=" + result.quantLevel + ")";
            }
        }
        writer.write("   Overall best reconstruction quality: " + bestPredictorMSE + "\n");
        writer.write("   with MSE = " + String.format("%.4f", bestMSE) + "\n\n");
        
        writer.write("5. Trade-offs:\n");
        writer.write("   - There is a trade-off between compression ratio and reconstruction quality.\n");
        writer.write("   - Higher quantization levels (32) provide the best quality but lowest compression.\n");
        writer.write("   - Lower quantization levels (8) provide higher compression but lower quality.\n");
        writer.write("   - The Adaptive 2-D predictor generally provides the best reconstruction quality.\n");
        writer.write("   - Order-2 predictor shows slight improvement over Order-1 in most cases.\n\n");
        
        writer.write("==============================================\n");
        writer.write("Generated Output Files\n");
        writer.write("==============================================\n\n");
        
        writer.write("All reconstructed images are saved in the 'output/' directory:\n\n");
        for (TestResult result : results) {
            writer.write("- " + result.outputFileName + "\n");
        }
        
        writer.write("\n==============================================\n");
        writer.write("Code Implementation\n");
        writer.write("==============================================\n\n");
        writer.write("The implementation includes:\n");
        writer.write("- PredictiveCoding.java: Main implementation with encoder and decoder\n");
        writer.write("- TestPredictiveCoding.java: Test harness for running all combinations\n");
        writer.write("\nKey functions:\n");
        writer.write("- convertToGrayscale(): Converts RGB image to grayscale\n");
        writer.write("- performPredictiveCoding(): Encodes and decodes using predictive coding\n");
        writer.write("- predictPixel(): Implements Order-1, Order-2, and Adaptive predictors\n");
        writer.write("- quantizeError() / dequantizeError(): Uniform scalar quantization\n");
        writer.write("- calculateMSE(): Computes Mean Squared Error\n");
        writer.write("- calculateCompressionRatio(): Computes compression ratio\n");
        
        writer.close();
    }
    
    static class TestResult {
        int predictorType;
        int quantLevel;
        double mse;
        double compressionRatio;
        double psnr;
        String outputFileName;
        
        public TestResult(int predictorType, int quantLevel, double mse, 
                         double compressionRatio, double psnr, String outputFileName) {
            this.predictorType = predictorType;
            this.quantLevel = quantLevel;
            this.mse = mse;
            this.compressionRatio = compressionRatio;
            this.psnr = psnr;
            this.outputFileName = outputFileName;
        }
    }
}
