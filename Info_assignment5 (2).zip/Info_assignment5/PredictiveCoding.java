import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import java.util.Scanner;

public class PredictiveCoding {
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Get user input
        System.out.print("Enter input image path: ");
        String imagePath = scanner.nextLine();
        
        System.out.print("Enter predictor type (1 for Order-1, 2 for Order-2, 3 for Adaptive): ");
        int predictorType = scanner.nextInt();
        
        System.out.print("Enter number of quantization levels (8, 16, 32): ");
        int quantLevels = scanner.nextInt();
        
        try {
            // Load image
            BufferedImage originalImage = ImageIO.read(new File(imagePath));
            int width = originalImage.getWidth();
            int height = originalImage.getHeight();
            
            System.out.println("\nImage loaded: " + width + "x" + height);
            
            // Convert to grayscale
            int[][] originalPixels = convertToGrayscale(originalImage, width, height);
            
            // Perform predictive coding
            PredictiveCodingResult result = performPredictiveCoding(
                originalPixels, width, height, predictorType, quantLevels
            );
            
            // Calculate metrics
            double mse = calculateMSE(originalPixels, result.reconstructedPixels, width, height);
            double compressionRatio = calculateCompressionRatio(
                originalPixels, result.encodedData, width, height, quantLevels
            );
            
            // Create output directory if it doesn't exist
            File outputDir = new File("output");
            if (!outputDir.exists()) {
                outputDir.mkdir();
            }
            
            // Save reconstructed image
            BufferedImage reconstructedImage = createBufferedImage(result.reconstructedPixels, width, height);
            ImageIO.write(reconstructedImage, "png", new File("output/reconstructed_" + predictorType + "_" + quantLevels + ".png"));
            
            // Display results
            System.out.println("\n=== Results ===");
            System.out.println("Predictor Type: " + getPredictorName(predictorType));
            System.out.println("Quantization Levels: " + quantLevels);
            System.out.println("Mean Squared Error (MSE): " + mse);
            System.out.println("Compression Ratio: " + compressionRatio);
            System.out.println("Original Size: " + (width * height) + " bytes");
            System.out.println("Encoded Size: " + result.encodedData.length + " bytes");
            System.out.println("\nReconstructed image saved as: output/reconstructed_" + predictorType + "_" + quantLevels + ".png");
            
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        }
        
        scanner.close();
    }
    
    public static int[][] convertToGrayscale(BufferedImage image, int width, int height) {
        int[][] pixels = new int[height][width];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int rgb = image.getRGB(x, y);
                int r = (rgb >> 16) & 0xFF;
                int g = (rgb >> 8) & 0xFF;
                int b = rgb & 0xFF;
                // Luminance method
                int gray = (int)(0.299 * r + 0.587 * g + 0.114 * b);
                pixels[y][x] = gray;
            }
        }
        return pixels;
    }
    
    public static PredictiveCodingResult performPredictiveCoding(
        int[][] originalPixels, int width, int height, int predictorType, int quantLevels
    ) {
        int[][] reconstructedPixels = new int[height][width];
        int[][] encodedData = new int[height][width];
        
        // Calculate quantization step size
        int maxError = 255;
        int quantStep = maxError / quantLevels;
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                // Predict using reconstructed pixels (standard DPCM with feedback)
                int predicted = predictPixel(reconstructedPixels, x, y, predictorType);
                int actual = originalPixels[y][x];
                int error = actual - predicted;
                
                // Quantize the error
                int quantizedError = quantizeError(error, quantStep);
                encodedData[y][x] = quantizedError;
                
                // Dequantize
                int dequantizedError = dequantizeError(quantizedError, quantStep);
                
                // Reconstruct pixel
                int reconstructed = predicted + dequantizedError;
                reconstructed = Math.max(0, Math.min(255, reconstructed));
                reconstructedPixels[y][x] = reconstructed;
            }
        }
        
        return new PredictiveCodingResult(reconstructedPixels, encodedData);
    }
    
    public static int predictPixel(int[][] pixels, int x, int y, int predictorType) {
        int width = pixels[0].length;
        int height = pixels.length;
        
        // Handle boundary conditions
        if (x == 0 && y == 0) {
            return 128; // Default for first pixel
        }
        
        int a = (x > 0) ? pixels[y][x-1] : 128;           // Left
        int b = (y > 0) ? pixels[y-1][x] : 128;           // Top
        int c = (x > 0 && y > 0) ? pixels[y-1][x-1] : 128; // Top-left
        
        switch (predictorType) {
            case 1: // Order-1: P(i,j) = Pixel(i,j-1)
                return a;
                
            case 2: // Order-2: P(i,j) = Pixel(i,j-1) + Pixel(i-1,j) - Pixel(i-1,j-1)
                return a + b - c;
                
            case 3: // Adaptive 2-D Predictor
                return adaptivePredictor(a, b, c);
                
            default:
                return a;
        }
    }
    
    public static int adaptivePredictor(int a, int b, int c) {
        int minAC = Math.min(a, c);
        int maxAC = Math.max(a, c);
        
        if (b <= minAC) {
            return maxAC;
        } else if (b >= maxAC) {
            return minAC;
        } else {
            return a + c - b;
        }
    }
    
    public static int quantizeError(int error, int quantStep) {
        int quantized = (int)Math.round((double)error / quantStep);
        return quantized;
    }
    
    public static int dequantizeError(int quantizedError, int quantStep) {
        return quantizedError * quantStep;
    }
    
    public static double calculateMSE(int[][] original, int[][] reconstructed, int width, int height) {
        double sumSquaredError = 0;
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int error = original[y][x] - reconstructed[y][x];
                sumSquaredError += error * error;
            }
        }
        return sumSquaredError / (width * height);
    }
    
    public static double calculateCompressionRatio(int[][] original, int[][] encoded, int width, int height, int quantLevels) {
        // Original size: each pixel is 1 byte (8 bits)
        long originalSize = width * height * 8L;
        
        // Calculate encoded size based on the actual range of quantized errors
        // Better predictors should have smaller error ranges
        int minValue = Integer.MAX_VALUE;
        int maxValue = Integer.MIN_VALUE;
        
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                minValue = Math.min(minValue, encoded[y][x]);
                maxValue = Math.max(maxValue, encoded[y][x]);
            }
        }
        
        int range = maxValue - minValue + 1;
        int bitsPerSymbol = (int)Math.ceil(Math.log(range) / Math.log(2));
        
        long encodedSize = width * height * bitsPerSymbol;
        
        return (double)originalSize / encodedSize;
    }
    
    public static BufferedImage createBufferedImage(int[][] pixels, int width, int height) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int gray = pixels[y][x];
                int rgb = (gray << 16) | (gray << 8) | gray;
                image.setRGB(x, y, rgb);
            }
        }
        return image;
    }
    
    public static String getPredictorName(int type) {
        switch (type) {
            case 1: return "Order-1";
            case 2: return "Order-2";
            case 3: return "Adaptive 2-D";
            default: return "Unknown";
        }
    }
    
    static class PredictiveCodingResult {
        int[][] reconstructedPixels;
        int[][] encodedData;
        
        public PredictiveCodingResult(int[][] reconstructedPixels, int[][] encodedData) {
            this.reconstructedPixels = reconstructedPixels;
            this.encodedData = encodedData;
        }
    }
}
