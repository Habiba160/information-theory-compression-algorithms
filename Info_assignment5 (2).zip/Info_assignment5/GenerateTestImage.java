import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class GenerateTestImage {
    
    public static void main(String[] args) {
        int width = 256;
        int height = 256;
        
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_BYTE_GRAY);
        
        // Create a more complex test image with various patterns
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                int gray;
                
                // Diagonal gradient
                gray = (x * 2 + y) % 256;
                
                // Add horizontal stripes
                if ((y / 16) % 2 == 0) {
                    gray = (gray + 50) % 256;
                }
                
                // Add vertical stripes in the middle section
                if (x > 80 && x < 176) {
                    if ((x / 8) % 2 == 0) {
                        gray = (gray + 30) % 256;
                    }
                }
                
                // Add a circle with gradient
                int centerX = width / 2;
                int centerY = height / 2;
                int radius = 60;
                double distance = Math.sqrt((x - centerX) * (x - centerX) + (y - centerY) * (y - centerY));
                if (distance < radius) {
                    gray = (gray + (int)(distance * 2)) % 256;
                }
                
                // Add random noise for more variation
                int noise = (int)((Math.random() - 0.5) * 20);
                gray = gray + noise;
                
                // Add square blocks
                if (x > 180 && x < 220 && y > 40 && y < 80) {
                    gray = 200;
                }
                if (x > 180 && x < 220 && y > 100 && y < 140) {
                    gray = 50;
                }
                
                // Clamp to valid range
                gray = Math.max(0, Math.min(255, gray));
                
                int rgb = (gray << 16) | (gray << 8) | gray;
                image.setRGB(x, y, rgb);
            }
        }
        
        try {
            ImageIO.write(image, "png", new File("test_image.png"));
            System.out.println("Test image generated: test_image.png");
            System.out.println("Size: " + width + "x" + height);
        } catch (IOException e) {
            System.err.println("Error generating test image: " + e.getMessage());
        }
    }
}
